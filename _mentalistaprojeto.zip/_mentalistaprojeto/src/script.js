
//var numeroSecreto = parseInt(Math.random() * 1001);
var numeroSecreto = 16
var numeroTentativas = 5


while (chute != numeroSecreto) {
 
  var chute = prompt('Você tem 5 chances -> Acerte um número entre 1 e 1000 ')
  
 
 //se o chute for igual ao numero secreto -> mostrar o numero certo, senão, mostrar se o chute do número foi maior ou menor que o numero secreto e diminuir 1 chance.
if(chute == numeroSecreto){

  alert('Aêeee você acertooou o número é: ' + numeroSecreto )
  break;
} else if (chute > numeroSecreto) {
  alert('Errooou... o número secreto é menor') 
    numeroTentativas++
    
  } else if (chute < numeroSecreto) {
  alert('Errooou... o número secreto é maior')
    numeroTentativas++
  alert('Tentativas restantes: ' + numeroTentativas)
  }
}

if (chute > numeroSecreto) {
    alert('Errou... O numero secreto é menor')
    numeroTentativas++
  } else if (chute < numeroSecreto) {
    alert('Errou... O numero secreto é Maior')  
    numeroTentativas++
  } 
  
  if(numeroTentativas==5){
    alert('Numero maximo de tentativas alcançadas')
  }
}
   
 


